This folder contains additional files and code snippets used in the following docs:

[Docker](http://docs.microsoft.com/azure/devops/pipelines/languages/docker).
